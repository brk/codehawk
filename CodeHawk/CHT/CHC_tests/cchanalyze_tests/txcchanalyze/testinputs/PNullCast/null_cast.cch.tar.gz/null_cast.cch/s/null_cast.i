# 0 "/home/brk/cfs/codehawk-evidence/native-std-cpu1/20261110-step6-assumptions/repros/null-cast-before/null_cast/null_cast.c"
# 1 "/home/brk/cfs/codehawk-evidence/native-std-cpu1/20261110-step6-assumptions/repros/null-cast-before/null_cast//"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/brk/cfs/codehawk-evidence/native-std-cpu1/20261110-step6-assumptions/repros/null-cast-before/null_cast/null_cast.c"

# 1 "/usr/lib/gcc/x86_64-linux-gnu/13/include/stddef.h" 1 3 4
# 145 "/usr/lib/gcc/x86_64-linux-gnu/13/include/stddef.h" 3 4

# 145 "/usr/lib/gcc/x86_64-linux-gnu/13/include/stddef.h" 3 4
typedef long int ptrdiff_t;
# 214 "/usr/lib/gcc/x86_64-linux-gnu/13/include/stddef.h" 3 4
typedef long unsigned int size_t;
# 329 "/usr/lib/gcc/x86_64-linux-gnu/13/include/stddef.h" 3 4
typedef int wchar_t;
# 3 "/home/brk/cfs/codehawk-evidence/native-std-cpu1/20261110-step6-assumptions/repros/null-cast-before/null_cast/null_cast.c" 2

# 3 "/home/brk/cfs/codehawk-evidence/native-std-cpu1/20261110-step6-assumptions/repros/null-cast-before/null_cast/null_cast.c"
extern void needs_pointer(const char *p);
static char Global[2] = "x";
void null_direct_bad(void) { needs_pointer((const char *)0); }
void null_void_bad(void) { needs_pointer((const char *)(void *)0); }
void null_triple_bad(void) { needs_pointer((const char *)(char *)(void *)0); }
void null_macro_bad(void) { needs_pointer(
# 8 "/home/brk/cfs/codehawk-evidence/native-std-cpu1/20261110-step6-assumptions/repros/null-cast-before/null_cast/null_cast.c" 3 4
                                         ((void *)0)
# 8 "/home/brk/cfs/codehawk-evidence/native-std-cpu1/20261110-step6-assumptions/repros/null-cast-before/null_cast/null_cast.c"
                                             ); }
int dereference_direct_bad(void) { return *(const int *)0; }
int dereference_void_bad(void) { return *(const int *)(void *)0; }
void local_good(void) { char Local[2]="x"; needs_pointer(Local); }
void global_good(void) { needs_pointer(Global); }
void literal_good(void) { needs_pointer("x"); }
void cast_local_good(void) { char Local[2]="x"; needs_pointer((const char *)(void *)Local); }
