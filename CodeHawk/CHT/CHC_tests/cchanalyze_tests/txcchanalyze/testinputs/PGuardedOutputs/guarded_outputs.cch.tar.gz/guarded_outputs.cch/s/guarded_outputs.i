# 0 "/home/brk/cfs/codehawk-evidence/native-std-cpu1/20261109-lc-guarded-outputs/repros/guarded-expanded-reviewed/guarded_outputs/guarded_outputs.c"
# 1 "/home/brk/cfs/codehawk-evidence/native-std-cpu1/20261109-lc-guarded-outputs/repros/guarded-expanded-reviewed/guarded_outputs//"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/brk/cfs/codehawk-evidence/native-std-cpu1/20261109-lc-guarded-outputs/repros/guarded-expanded-reviewed/guarded_outputs/guarded_outputs.c"

# 1 "/usr/lib/gcc/x86_64-linux-gnu/13/include/stdint.h" 1 3 4
# 9 "/usr/lib/gcc/x86_64-linux-gnu/13/include/stdint.h" 3 4
# 1 "/usr/include/stdint.h" 1 3 4
# 26 "/usr/include/stdint.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 33 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 3 4
# 1 "/usr/include/features.h" 1 3 4
# 394 "/usr/include/features.h" 3 4
# 1 "/usr/include/features-time64.h" 1 3 4
# 20 "/usr/include/features-time64.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 21 "/usr/include/features-time64.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 1 3 4
# 19 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 2 3 4
# 22 "/usr/include/features-time64.h" 2 3 4
# 395 "/usr/include/features.h" 2 3 4
# 502 "/usr/include/features.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 1 3 4
# 576 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 577 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/long-double.h" 1 3 4
# 578 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 2 3 4
# 503 "/usr/include/features.h" 2 3 4
# 526 "/usr/include/features.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 1 3 4
# 10 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/gnu/stubs-64.h" 1 3 4
# 11 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 2 3 4
# 527 "/usr/include/features.h" 2 3 4
# 34 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 2 3 4
# 27 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types.h" 1 3 4
# 27 "/usr/include/x86_64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 28 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 1 3 4
# 19 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 2 3 4
# 29 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4



# 31 "/usr/include/x86_64-linux-gnu/bits/types.h" 3 4
typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;


typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;

typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;






typedef __int8_t __int_least8_t;
typedef __uint8_t __uint_least8_t;
typedef __int16_t __int_least16_t;
typedef __uint16_t __uint_least16_t;
typedef __int32_t __int_least32_t;
typedef __uint32_t __uint_least32_t;
typedef __int64_t __int_least64_t;
typedef __uint64_t __uint_least64_t;



typedef long int __quad_t;
typedef unsigned long int __u_quad_t;







typedef long int __intmax_t;
typedef unsigned long int __uintmax_t;
# 141 "/usr/include/x86_64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/typesizes.h" 1 3 4
# 142 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/time64.h" 1 3 4
# 143 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned long int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;
typedef long int __suseconds64_t;

typedef int __daddr_t;
typedef int __key_t;


typedef int __clockid_t;


typedef void * __timer_t;


typedef long int __blksize_t;




typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;


typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;


typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;


typedef long int __fsword_t;

typedef long int __ssize_t;


typedef long int __syscall_slong_t;

typedef unsigned long int __syscall_ulong_t;



typedef __off64_t __loff_t;
typedef char *__caddr_t;


typedef long int __intptr_t;


typedef unsigned int __socklen_t;




typedef int __sig_atomic_t;
# 28 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wchar.h" 1 3 4
# 29 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 30 "/usr/include/stdint.h" 2 3 4




# 1 "/usr/include/x86_64-linux-gnu/bits/stdint-intn.h" 1 3 4
# 24 "/usr/include/x86_64-linux-gnu/bits/stdint-intn.h" 3 4
typedef __int8_t int8_t;
typedef __int16_t int16_t;
typedef __int32_t int32_t;
typedef __int64_t int64_t;
# 35 "/usr/include/stdint.h" 2 3 4


# 1 "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h" 1 3 4
# 24 "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h" 3 4
typedef __uint8_t uint8_t;
typedef __uint16_t uint16_t;
typedef __uint32_t uint32_t;
typedef __uint64_t uint64_t;
# 38 "/usr/include/stdint.h" 2 3 4



# 1 "/usr/include/x86_64-linux-gnu/bits/stdint-least.h" 1 3 4
# 25 "/usr/include/x86_64-linux-gnu/bits/stdint-least.h" 3 4
typedef __int_least8_t int_least8_t;
typedef __int_least16_t int_least16_t;
typedef __int_least32_t int_least32_t;
typedef __int_least64_t int_least64_t;


typedef __uint_least8_t uint_least8_t;
typedef __uint_least16_t uint_least16_t;
typedef __uint_least32_t uint_least32_t;
typedef __uint_least64_t uint_least64_t;
# 42 "/usr/include/stdint.h" 2 3 4





typedef signed char int_fast8_t;

typedef long int int_fast16_t;
typedef long int int_fast32_t;
typedef long int int_fast64_t;
# 60 "/usr/include/stdint.h" 3 4
typedef unsigned char uint_fast8_t;

typedef unsigned long int uint_fast16_t;
typedef unsigned long int uint_fast32_t;
typedef unsigned long int uint_fast64_t;
# 76 "/usr/include/stdint.h" 3 4
typedef long int intptr_t;


typedef unsigned long int uintptr_t;
# 90 "/usr/include/stdint.h" 3 4
typedef __intmax_t intmax_t;
typedef __uintmax_t uintmax_t;
# 10 "/usr/lib/gcc/x86_64-linux-gnu/13/include/stdint.h" 2 3 4
# 3 "/home/brk/cfs/codehawk-evidence/native-std-cpu1/20261109-lc-guarded-outputs/repros/guarded-expanded-reviewed/guarded_outputs/guarded_outputs.c" 2
# 1 "/usr/lib/gcc/x86_64-linux-gnu/13/include/stddef.h" 1 3 4
# 145 "/usr/lib/gcc/x86_64-linux-gnu/13/include/stddef.h" 3 4
typedef long int ptrdiff_t;
# 214 "/usr/lib/gcc/x86_64-linux-gnu/13/include/stddef.h" 3 4
typedef long unsigned int size_t;
# 329 "/usr/lib/gcc/x86_64-linux-gnu/13/include/stddef.h" 3 4
typedef int wchar_t;
# 4 "/home/brk/cfs/codehawk-evidence/native-std-cpu1/20261109-lc-guarded-outputs/repros/guarded-expanded-reviewed/guarded_outputs/guarded_outputs.c" 2

# 4 "/home/brk/cfs/codehawk-evidence/native-std-cpu1/20261109-lc-guarded-outputs/repros/guarded-expanded-reviewed/guarded_outputs/guarded_outputs.c"
extern int acquire(void **out);
extern int acquire_zero(void **out);
extern int acquire_negative(void **out);
extern void opaque(void);
void *success_good(void) { void *p; int r=acquire(&p); if(r<0)return 0; return p; }
void *failure_bad(void) { void *p; int r=acquire(&p); if(r>=0)return 0; return p; }
void *unguarded_bad(void) { void *p; acquire(&p); return p; }
void *wrong_call_bad(void) { void *p,*q; int r=acquire(&p); int s=acquire(&q); if(s<0)return 0; (void)r; return p; }
void *overwritten_status_bad(void) { void *p; int r=acquire(&p); r=0; if(r<0)return 0; return p; }
void *saved_status_good(void) { void *p; int r=acquire(&p),s=r; r=-1; if(s<0)return 0; return p; }
void *field_good(void) { struct {void *p,*q;} d; int r=acquire(&d.p); if(r<0)return 0; return d.p; }
void *sibling_bad(void) { struct {void *p,*q;} d; int r=acquire(&d.p); if(r<0)return 0; return d.q; }
void *zero_good(void) { void *p; int r=acquire_zero(&p); if(r!=0)return 0; return p; }
void *zero_error_bad(void) { void *p; int r=acquire_zero(&p); if(r==0)return 0; return p; }
void *negative_good(void) { void *p; int r=acquire_negative(&p); if(r>=0)return 0; return p; }
void *narrow_status_unknown(void) { void *p; unsigned char r=(unsigned char)acquire(&p); if(r!=0)return 0; return p; }
extern int acquire_positive(void **out);
extern int acquire_nonpositive(void **out);
extern int acquire_nonzero(void **out);
extern int acquire_19(void **out);
extern int acquire_framed(void **out);
extern int status_only(void);
extern void readonly_call(void);
void *direct_if_good(void) { void *p; if(acquire(&p)<0)return 0; return p; }
void *positive_good(void) { void *p; int r=acquire_positive(&p); if(r<=0)return 0; return p; }
void *nonpositive_good(void) { void *p; int r=acquire_nonpositive(&p); if(r>0)return 0; return p; }
void *nonzero_good(void) { void *p; int r=acquire_nonzero(&p); if(r<=0)return 0; return p; }
void *constant_good(void) { void *p; int r=acquire_19(&p); if(r!=19)return 0; return p; }
void *wider_status_good(void) { void *p; long r=acquire(&p); if(r<0)return 0; return p; }
void *struct_status_good(void) { void *p; struct {int r;} s; s.r=acquire(&p); if(s.r<0)return 0; return p; }
void *readonly_good(void) { void *p; int r=acquire(&p); if(r<0)return 0; readonly_call(); return p; }
void *opaque_bad(void) { void *p; int r=acquire(&p); if(r<0)return 0; opaque(); return p; }
void *different_call_bad(void) { void *p,*q; int r=acquire_framed(&p),s=acquire_framed(&q); if(s<0)return 0; (void)r; return p; }
void *both_framed_good(void) { void *p,*q; int r=acquire_framed(&p),s=acquire_framed(&q); if(r<0||s<0)return 0; return p; }
void *status_only_bad(void) { void *p; int r=acquire(&p); r=status_only(); if(r<0)return 0; return p; }
void *normalized_error_bad(void) { void *p; int r=acquire(&p); if(r<0)r=0; if(r<0)return 0; return p; }
void *bool_status_bad(void) { void *p; _Bool r=acquire(&p); if(!r)return 0; return p; }
void *signed_narrow_bad(void) { void *p; int8_t r=(int8_t)acquire(&p); if(r<0)return 0; return p; }
void *unsigned_status_bad(void) { void *p; unsigned int r=(unsigned int)acquire(&p); if(r>100)return 0; return p; }
void *masked_status_bad(void) { void *p; int r=acquire(&p); r&=0; if(r<0)return 0; return p; }
void *arithmetic_status_bad(void) { void *p; int r=acquire(&p); if(r>0)return 0; r+=1; if(r<0)return 0; return p; }
void *partial_status_bad(void) { void *p; int r=acquire(&p); ((unsigned char*)&r)[0]=0; if(r<0)return 0; return p; }
void *union_status_bad(void) { void *p; union {int r;unsigned bits;} u; u.r=acquire(&p); u.bits=0; if(u.r<0)return 0; return p; }
void *volatile_status_unknown(void) { void *p; volatile int r=acquire(&p); if(r<0)return 0; return p; }
void *loop_status_unknown(void) { void *p; int previous=0; for(int i=0;i<2;++i) { int r=acquire(&p); if(previous<0)return 0; previous=r; } return p; }
void *branch_gap_bad(int c) { void *p; int r=0; if(c)r=acquire(&p); if(r<0)return 0; return p; }
uint32_t payload_bad(void) { void *p; int r=acquire(&p); if(r<0)return 0; return *(uint32_t*)p; }
typedef struct {void *p;void *q;} Descriptor;
extern int acquire_descriptor(Descriptor *out);
void *descriptor_good(void) { Descriptor d; int r=acquire_descriptor(&d); if(r<0)return 0; return d.p; }
void *descriptor_sibling_bad(void) { Descriptor d; int r=acquire_descriptor(&d); if(r<0)return 0; return d.q; }
extern void release(void *p);
void *nonzero_error_bad(void) { void *p; int r=acquire_nonzero(&p); if(r!=0)return 0; return p; }
void *released_bad(void) { void *p; int r=acquire(&p); if(r<0)return 0; release(p); return p; }
typedef union {uint32_t bits;uint16_t half;} Data;
extern int acquire_narrow(Data *out);
uint32_t narrow_field_bad(void) { Data d; int r=acquire_narrow(&d); if(r<0)return 0; return d.bits; }
void *checked_then_changed_good(void) { void *p; int r=acquire(&p); if(r<0)return 0; r=0; return p; }
