# 0 "/home/brk/cfs/codehawk-evidence/native-std-cpu1/20261111-step6-correlated-bytes/repros/correlated-complete-after/correlated_union_legacy/correlated_union_legacy.c"
# 1 "/home/brk/cfs/codehawk-evidence/native-std-cpu1/20261111-step6-correlated-bytes/repros/correlated-complete-after/correlated_union_legacy//"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/brk/cfs/codehawk-evidence/native-std-cpu1/20261111-step6-correlated-bytes/repros/correlated-complete-after/correlated_union_legacy/correlated_union_legacy.c"
# 1 "/usr/lib/gcc/x86_64-linux-gnu/13/include/stdint.h" 1 3 4
# 9 "/usr/lib/gcc/x86_64-linux-gnu/13/include/stdint.h" 3 4
# 1 "/usr/include/stdint.h" 1 3 4
# 26 "/usr/include/stdint.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 33 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 3 4
# 1 "/usr/include/features.h" 1 3 4
# 394 "/usr/include/features.h" 3 4
# 1 "/usr/include/features-time64.h" 1 3 4
# 20 "/usr/include/features-time64.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 21 "/usr/include/features-time64.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 1 3 4
# 19 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 2 3 4
# 22 "/usr/include/features-time64.h" 2 3 4
# 395 "/usr/include/features.h" 2 3 4
# 502 "/usr/include/features.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 1 3 4
# 576 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 577 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/long-double.h" 1 3 4
# 578 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 2 3 4
# 503 "/usr/include/features.h" 2 3 4
# 526 "/usr/include/features.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 1 3 4
# 10 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/gnu/stubs-64.h" 1 3 4
# 11 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 2 3 4
# 527 "/usr/include/features.h" 2 3 4
# 34 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 2 3 4
# 27 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types.h" 1 3 4
# 27 "/usr/include/x86_64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 28 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 1 3 4
# 19 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 2 3 4
# 29 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4



# 31 "/usr/include/x86_64-linux-gnu/bits/types.h" 3 4
typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;


typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;

typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;






typedef __int8_t __int_least8_t;
typedef __uint8_t __uint_least8_t;
typedef __int16_t __int_least16_t;
typedef __uint16_t __uint_least16_t;
typedef __int32_t __int_least32_t;
typedef __uint32_t __uint_least32_t;
typedef __int64_t __int_least64_t;
typedef __uint64_t __uint_least64_t;



typedef long int __quad_t;
typedef unsigned long int __u_quad_t;







typedef long int __intmax_t;
typedef unsigned long int __uintmax_t;
# 141 "/usr/include/x86_64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/typesizes.h" 1 3 4
# 142 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/time64.h" 1 3 4
# 143 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned long int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;
typedef long int __suseconds64_t;

typedef int __daddr_t;
typedef int __key_t;


typedef int __clockid_t;


typedef void * __timer_t;


typedef long int __blksize_t;




typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;


typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;


typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;


typedef long int __fsword_t;

typedef long int __ssize_t;


typedef long int __syscall_slong_t;

typedef unsigned long int __syscall_ulong_t;



typedef __off64_t __loff_t;
typedef char *__caddr_t;


typedef long int __intptr_t;


typedef unsigned int __socklen_t;




typedef int __sig_atomic_t;
# 28 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wchar.h" 1 3 4
# 29 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 30 "/usr/include/stdint.h" 2 3 4




# 1 "/usr/include/x86_64-linux-gnu/bits/stdint-intn.h" 1 3 4
# 24 "/usr/include/x86_64-linux-gnu/bits/stdint-intn.h" 3 4
typedef __int8_t int8_t;
typedef __int16_t int16_t;
typedef __int32_t int32_t;
typedef __int64_t int64_t;
# 35 "/usr/include/stdint.h" 2 3 4


# 1 "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h" 1 3 4
# 24 "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h" 3 4
typedef __uint8_t uint8_t;
typedef __uint16_t uint16_t;
typedef __uint32_t uint32_t;
typedef __uint64_t uint64_t;
# 38 "/usr/include/stdint.h" 2 3 4



# 1 "/usr/include/x86_64-linux-gnu/bits/stdint-least.h" 1 3 4
# 25 "/usr/include/x86_64-linux-gnu/bits/stdint-least.h" 3 4
typedef __int_least8_t int_least8_t;
typedef __int_least16_t int_least16_t;
typedef __int_least32_t int_least32_t;
typedef __int_least64_t int_least64_t;


typedef __uint_least8_t uint_least8_t;
typedef __uint_least16_t uint_least16_t;
typedef __uint_least32_t uint_least32_t;
typedef __uint_least64_t uint_least64_t;
# 42 "/usr/include/stdint.h" 2 3 4





typedef signed char int_fast8_t;

typedef long int int_fast16_t;
typedef long int int_fast32_t;
typedef long int int_fast64_t;
# 60 "/usr/include/stdint.h" 3 4
typedef unsigned char uint_fast8_t;

typedef unsigned long int uint_fast16_t;
typedef unsigned long int uint_fast32_t;
typedef unsigned long int uint_fast64_t;
# 76 "/usr/include/stdint.h" 3 4
typedef long int intptr_t;


typedef unsigned long int uintptr_t;
# 90 "/usr/include/stdint.h" 3 4
typedef __intmax_t intmax_t;
typedef __uintmax_t uintmax_t;
# 10 "/usr/lib/gcc/x86_64-linux-gnu/13/include/stdint.h" 2 3 4
# 2 "/home/brk/cfs/codehawk-evidence/native-std-cpu1/20261111-step6-correlated-bytes/repros/correlated-complete-after/correlated_union_legacy/correlated_union_legacy.c" 2
# 1 "/usr/include/string.h" 1 3 4
# 26 "/usr/include/string.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/string.h" 2 3 4






# 1 "/usr/lib/gcc/x86_64-linux-gnu/13/include/stddef.h" 1 3 4
# 214 "/usr/lib/gcc/x86_64-linux-gnu/13/include/stddef.h" 3 4
typedef long unsigned int size_t;
# 34 "/usr/include/string.h" 2 3 4
# 43 "/usr/include/string.h" 3 4
extern void *memcpy (void *__restrict __dest, const void *__restrict __src,
       size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern void *memmove (void *__dest, const void *__src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
# 61 "/usr/include/string.h" 3 4
extern void *memset (void *__s, int __c, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int memcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 80 "/usr/include/string.h" 3 4
extern int __memcmpeq (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 107 "/usr/include/string.h" 3 4
extern void *memchr (const void *__s, int __c, size_t __n)
      __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 141 "/usr/include/string.h" 3 4
extern char *strcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *strncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern char *strcat (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *strncat (char *__restrict __dest, const char *__restrict __src,
        size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strcmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern int strncmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strcoll (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern size_t strxfrm (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
    __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) __attribute__ ((__access__ (__write_only__, 1, 3)));
# 246 "/usr/include/string.h" 3 4
extern char *strchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 273 "/usr/include/string.h" 3 4
extern char *strrchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 293 "/usr/include/string.h" 3 4
extern size_t strcspn (const char *__s, const char *__reject)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern size_t strspn (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 323 "/usr/include/string.h" 3 4
extern char *strpbrk (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 350 "/usr/include/string.h" 3 4
extern char *strstr (const char *__haystack, const char *__needle)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));




extern char *strtok (char *__restrict __s, const char *__restrict __delim)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));



extern char *__strtok_r (char *__restrict __s,
    const char *__restrict __delim,
    char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));
# 407 "/usr/include/string.h" 3 4
extern size_t strlen (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 419 "/usr/include/string.h" 3 4
extern char *strerror (int __errnum) __attribute__ ((__nothrow__ , __leaf__));
# 552 "/usr/include/string.h" 3 4

# 3 "/home/brk/cfs/codehawk-evidence/native-std-cpu1/20261111-step6-correlated-bytes/repros/correlated-complete-after/correlated_union_legacy/correlated_union_legacy.c" 2

# 3 "/home/brk/cfs/codehawk-evidence/native-std-cpu1/20261111-step6-correlated-bytes/repros/correlated-complete-after/correlated_union_legacy/correlated_union_legacy.c"
union sample { uint8_t byte; uint16_t half; uint32_t word; float floating; };
unsigned Kind;
extern uint32_t consume(union sample *value);
extern uint32_t consume_word(uint32_t *value);
extern void event(void);

uint32_t cleared_union(void)
{
    union sample value;
    memset(&value, 0, sizeof(value));
    return consume(&value);
}

uint32_t scalar_word(uint32_t input)
{
    uint32_t value = input;
    return consume_word(&value);
}

uint32_t constant_member(void)
{
    union sample value;
    value.word = 42;
    return consume(&value);
}

uint32_t whole_member(uint32_t input)
{
    union sample value;
    value.word = input;
    return consume(&value);
}

uint32_t correlated_parameter(unsigned kind, uint32_t input)
{
    union sample value;
    switch (kind)
    {
        case 1: value.byte = input & 255; break;
        case 2: value.half = input & 65535; break;
        default: value.word = input; break;
    }
    switch (kind)
    {
        case 3: return consume(&value);
        default: return 0;
    }
}

uint32_t correlated_global(uint32_t input)
{
    union sample value;
    switch (Kind)
    {
        case 1: value.byte = input & 255; break;
        case 2: value.half = input & 65535; break;
        default: value.word = input; break;
    }
    switch (Kind)
    {
        case 3: return consume(&value);
        default: return 0;
    }
}

uint32_t changed_selector(uint32_t input)
{
    union sample value;
    switch (Kind)
    {
        case 1: value.byte = input & 255; break;
        case 2: value.half = input & 65535; break;
        default: value.word = input; break;
    }
    Kind = 3;
    return consume(&value);
}

uint32_t opaque_selector(uint32_t input)
{
    union sample value;
    switch (Kind)
    {
        case 1: value.byte = input & 255; break;
        case 2: value.half = input & 65535; break;
        default: value.word = input; break;
    }
    event();
    switch (Kind)
    {
        case 3: return consume(&value);
        default: return 0;
    }
}

uint32_t short_member(uint32_t input)
{
    union sample value;
    value.byte = input & 255;
    return consume(&value);
}

uint32_t uninitialized_member(void)
{
    union sample value;
    uint32_t unknown;
    value.word = unknown;
    return consume(&value);
}

uint32_t single_guard(unsigned kind, uint32_t input)
{
    union sample value;
    if (kind == 3)
    {
        value.word = input;
        return consume(&value);
    }
    return 0;
}
# 131 "/home/brk/cfs/codehawk-evidence/native-std-cpu1/20261111-step6-correlated-bytes/repros/correlated-complete-after/correlated_union_legacy/correlated_union_legacy.c"
struct entry { unsigned kind; union sample comparison; };
const struct entry *Entries;
const volatile struct entry *VolatileEntries;
volatile unsigned VolatileKind;
union sample *Escaped;
extern void publish(union sample *value);
extern uint32_t consume_pair(union sample *first, union sample *second);

uint32_t descriptor_copy(unsigned index, uint32_t input)
{
    union sample value, other;
    switch (Entries[index].kind) { case 1: value.byte = input & 255; break; case 2: value.half = input & 65535; break; default: value.word = input; break; }
    memcpy(&other, &Entries[index].comparison, 4);
    switch (Entries[index].kind)
    {
        case 3: return consume_pair(&value, &other);
        default: return 0;
    }
}

uint32_t multiple_query_cases(unsigned kind, uint32_t input)
{
    union sample value;
    switch (kind) { case 1: value.byte = input & 255; break; case 2: value.half = input & 65535; break; default: value.word = input; break; }
    switch (kind) { case 3: case 4: return consume(&value); default: return 0; }
}

uint32_t first_fallthrough_full(unsigned kind, uint32_t input)
{
    union sample value;
    switch (kind)
    {
        case 1: value.byte = input & 255; break;
        case 2: value.half = input & 65535; break;
        case 3: value.byte = input & 255;
        default: value.word = input; break;
    }
    switch (kind) { case 3: return consume(&value); default: return 0; }
}

uint32_t constant_default(unsigned kind, uint32_t input)
{
    union sample value;
    switch (kind) { case 1: value.byte = input & 255; break; default: value.word = 42; break; }
    switch (kind) { case 3: return consume(&value); default: return 0; }
}

uint32_t dirty_query_fallthrough(unsigned kind, uint32_t input)
{
    union sample value;
    switch (kind) { case 1: value.byte = input & 255; break; case 2: value.half = input & 65535; break; default: value.word = input; break; }
    switch (kind) { case 1: value.byte = 0; case 3: return consume(&value); default: return 0; }
}

uint32_t merged_query_labels(unsigned kind, uint32_t input)
{
    union sample value;
    switch (kind) { case 1: value.byte = input & 255; break; case 2: value.half = input & 65535; break; default: value.word = input; break; }
    switch (kind) { case 1: case 3: return consume(&value); default: return 0; }
}

uint32_t wrong_case_width(unsigned kind, uint32_t input)
{
    union sample value;
    switch (kind) { case 3: value.byte = input & 255; break; default: value.word = input; break; }
    switch (kind) { case 3: return consume(&value); default: return 0; }
}

uint32_t changed_via_alias(uint32_t input)
{
    union sample value;
    unsigned *alias = &Kind;
    switch (Kind) { case 1: value.byte = input & 255; break; case 2: value.half = input & 65535; break; default: value.word = input; break; }
    *alias = 3;
    switch (Kind) { case 3: return consume(&value); default: return 0; }
}

uint32_t volatile_selector(uint32_t input)
{
    union sample value;
    switch (VolatileKind) { case 1: value.byte = input & 255; break; case 2: value.half = input & 65535; break; default: value.word = input; break; }
    switch (VolatileKind) { case 3: return consume(&value); default: return 0; }
}

uint32_t volatile_descriptor(unsigned index, uint32_t input)
{
    union sample value;
    switch (VolatileEntries[index].kind) { case 1: value.byte = input & 255; break; case 2: value.half = input & 65535; break; default: value.word = input; break; }
    switch (VolatileEntries[index].kind) { case 3: return consume(&value); default: return 0; }
}

uint32_t changed_index(unsigned index, uint32_t input)
{
    union sample value;
    switch (Entries[index].kind) { case 1: value.byte = input & 255; break; case 2: value.half = input & 65535; break; default: value.word = input; break; }
    index = 0;
    switch (Entries[index].kind) { case 3: return consume(&value); default: return 0; }
}

uint32_t escaped_address(unsigned kind, uint32_t input)
{
    union sample value;
    publish(&value);
    switch (kind) { case 1: value.byte = input & 255; break; case 2: value.half = input & 65535; break; default: value.word = input; break; }
    switch (kind) { case 3: return consume(&value); default: return 0; }
}

uint32_t stored_address(unsigned kind, uint32_t input)
{
    union sample value;
    Escaped = &value;
    switch (kind) { case 1: value.byte = input & 255; break; case 2: value.half = input & 65535; break; default: value.word = input; break; }
    switch (kind) { case 3: return consume(&value); default: return 0; }
}

uint32_t partial_overwrite(unsigned kind, uint32_t input)
{
    union sample value;
    uint8_t unknown;
    switch (kind) { case 1: value.byte = input & 255; break; case 2: value.half = input & 65535; break; default: value.word = input; break; }
    memcpy(&value, &unknown, 1);
    switch (kind) { case 3: return consume(&value); default: return 0; }
}

uint32_t uninitialized_switch_word(unsigned kind, uint32_t input)
{
    union sample value;
    uint32_t unknown;
    switch (kind) { case 1: value.byte = input & 255; break; default: value.word = unknown; break; }
    switch (kind) { case 3: return consume(&value); default: return 0; }
}

uint32_t opaque_before_reads(unsigned kind, uint32_t input)
{
    union sample value;
    event();
    switch (kind) { case 1: value.byte = input & 255; break; case 2: value.half = input & 65535; break; default: value.word = input; break; }
    switch (kind) { case 3: return consume(&value); default: return 0; }
}

uint32_t loop_selector(unsigned kind, uint32_t input)
{
    union sample value;
    do { switch (kind) { case 1: value.byte = input & 255; break; case 2: value.half = input & 65535; break; default: value.word = input; break; } } while (kind--);
    switch (kind) { case 3: return consume(&value); default: return 0; }
}

uint32_t goto_selector(unsigned kind, uint32_t input)
{
    union sample value;
    switch (kind) { case 1: value.byte = input & 255; break; case 2: value.half = input & 65535; break; default: value.word = input; break; }
    goto query;
query:
    switch (kind) { case 3: return consume(&value); default: return 0; }
}

uint32_t asm_selector(unsigned kind, uint32_t input)
{
    union sample value;
    switch (kind) { case 1: value.byte = input & 255; break; case 2: value.half = input & 65535; break; default: value.word = input; break; }
    __asm__ volatile ("" ::: "memory");
    switch (kind) { case 3: return consume(&value); default: return 0; }
}

uint32_t nested_result(unsigned kind, uint32_t input)
{
    {
        union sample value;
        switch (kind) { case 1: value.byte = input & 255; break; case 2: value.half = input & 65535; break; default: value.word = input; break; }
        switch (kind) { case 3: return consume(&value); default: return 0; }
    }
}

uint32_t case_range(unsigned kind, uint32_t input)
{
    union sample value;
    switch (kind) { case 1 ... 2: value.half = input & 65535; break; default: value.word = input; break; }
    switch (kind) { case 3: return consume(&value); default: return 0; }
}

uint32_t copied_selector(unsigned initial, uint32_t input)
{
    union sample value;
    unsigned kind;
    unsigned three = 3;
    memcpy(&kind, &initial, sizeof(kind));
    switch (kind) { case 1: value.byte = input & 255; break; case 2: value.half = input & 65535; break; default: value.word = input; break; }
    memcpy(&kind, &three, sizeof(kind));
    switch (kind) { case 3: return consume(&value); default: return 0; }
}

const struct entry *OtherEntries;
uint32_t copied_pointer_selector(uint32_t input)
{
    union sample value;
    const struct entry *cursor;
    memcpy(&cursor, &Entries, sizeof(cursor));
    switch (cursor->kind) { case 1: value.byte = input & 255; break; case 2: value.half = input & 65535; break; default: value.word = input; break; }
    memcpy(&cursor, &OtherEntries, sizeof(cursor));
    switch (cursor->kind) { case 3: return consume(&value); default: return 0; }
}

uint32_t caller_initialized(void)
{
    return correlated_parameter(3, 42);
}

uint32_t caller_uninitialized(void)
{
    uint32_t unknown;
    return correlated_parameter(3, unknown);
}

uint32_t converted_case_label(unsigned kind, uint32_t input)
{
    union sample value;
    switch (kind) { case -1: value.byte = input & 255; break; default: value.word = input; break; }
    switch (kind) { case 
# 348 "/home/brk/cfs/codehawk-evidence/native-std-cpu1/20261111-step6-correlated-bytes/repros/correlated-complete-after/correlated_union_legacy/correlated_union_legacy.c" 3 4
                        (4294967295U)
# 348 "/home/brk/cfs/codehawk-evidence/native-std-cpu1/20261111-step6-correlated-bytes/repros/correlated-complete-after/correlated_union_legacy/correlated_union_legacy.c"
                                  : return consume(&value); default: return 0; }
}

uint32_t reverse_case_conversion(int kind, uint32_t input)
{
    union sample value;
    switch (kind) { case 
# 354 "/home/brk/cfs/codehawk-evidence/native-std-cpu1/20261111-step6-correlated-bytes/repros/correlated-complete-after/correlated_union_legacy/correlated_union_legacy.c" 3 4
                        (4294967295U)
# 354 "/home/brk/cfs/codehawk-evidence/native-std-cpu1/20261111-step6-correlated-bytes/repros/correlated-complete-after/correlated_union_legacy/correlated_union_legacy.c"
                                  : value.byte = input & 255; break; default: value.word = input; break; }
    switch (kind) { case -1: return consume(&value); default: return 0; }
}
