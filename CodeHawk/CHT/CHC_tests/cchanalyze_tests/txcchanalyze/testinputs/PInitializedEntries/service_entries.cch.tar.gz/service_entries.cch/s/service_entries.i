# 0 "/home/brk/cfs/codehawk-evidence/native-std-cpu1/20261109-lc-services/repros/entries-before/service_entries/service_entries.c"
# 1 "/home/brk/cfs/codehawk-evidence/native-std-cpu1/20261109-lc-services/repros/entries-before/service_entries//"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/brk/cfs/codehawk-evidence/native-std-cpu1/20261109-lc-services/repros/entries-before/service_entries/service_entries.c"

typedef struct { int value, sibling; } Pair;
extern void optional(int *out);
extern void field(Pair *out);
int entry_good(void) { int value=0; optional(&value); return value; }
int entry_bad(void) { int value; optional(&value); return value; }
int field_good(void) { Pair p; p.value=0; field(&p); return p.value; }
int field_bad(void) { Pair p; field(&p); return p.value; }
int sibling_bad(void) { Pair p; p.sibling=0; field(&p); return p.value; }
